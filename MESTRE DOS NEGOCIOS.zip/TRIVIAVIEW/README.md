# Mestre dos Negócios — Web

Jogo de perguntas 1v1 por turnos, versão web do jogo físico. Plano em [PLANO_TECNICO.md](PLANO_TECNICO.md).

## Comandos

| Comando | O que faz |
|---|---|
| `npm run dev` | Servidor local em http://localhost:5173 (modo hot-seat: dois jogadores no mesmo aparelho) |
| `npm test` | Testes: engine, API e SQL (RLS) num Postgres embutido |
| `npm run lint` | ESLint + checagem de tipos |
| `npm run build` | Build de produção + checagem de que o gabarito não vazou no bundle |
| `npm run questions` | `content/questions.source.json` → `server/questions.json` (valida o banco) |
| `npm run e2e:online` | Teste ponta a ponta do modo online (precisa de `npm run dev` e Supabase rodando) |
| `npm run images` | Gera WebP em `src/assets/` a partir de `MESTRE DOS NEGÓCIOS.zip` |

## Estrutura

```
content/        banco de perguntas original do jogo físico
server/         banco normalizado com gabarito — nunca importar em src/
src/engine/     regras puras (reduce, settle, toPublicView) + testes
src/game/       GameClient: local (hot-seat, só em dev) e remoto (Supabase + /api/game)
server/         lógica da API: validação, acesso, persistência (testada com repositório em memória)
api/game.ts     Vercel Function que expõe server/http.ts
supabase/       config local, migrations (tabelas, RLS, funções) e teste do SQL
src/screens/    Home e Partida (roleta, pergunta, coroa, duelo, fim)
src/ui/         componentes visuais (roleta, painel do jogador, fichas)
src/content/    nomes, cores e imagens das áreas
src/assets/     personagens e fichas em WebP
scripts/        normalização de perguntas e otimização de imagens
```

## Engine

```ts
import { createMatch, reduce, settle, toPublicView } from './src/engine'

let state = createMatch({ id, code, creatorId, creatorName, now })
const r = reduce(state, { type: 'SPIN', by: creatorId }, { now, rng, bank })
state = r.state            // r.spin, r.reveal, r.events para a UI
toPublicView(state, bank)  // seguro para enviar ao cliente
```

Comandos: `JOIN`, `SPIN`, `ANSWER`, `CHOOSE_CROWN`, `START_DUEL`, `DUEL_NEXT`, `RESIGN`.
Balanceamento em [src/engine/rules.ts](src/engine/rules.ts).

## Modo online (Supabase)

Arquitetura: o navegador entra com login anônimo do Supabase, envia jogadas para `POST /api/game`
(que roda a engine com a service role) e recebe as jogadas do rival por Realtime na tabela `matches`.
O gabarito e o estado completo (`match_state`) nunca saem do servidor.

### Opção A — Supabase local (precisa do Docker Desktop aberto)

```bash
npx supabase start
```

O comando aplica `supabase/migrations/` e mostra `API URL`, `anon key` e `service_role key`.
Copie para `.env.local` (modelo em `.env.example`) e rode `npm run dev`.

### Opção B — Projeto na nuvem (supabase.com, plano grátis, região São Paulo)

1. Crie o projeto.
2. **SQL Editor**: cole e rode `supabase/migrations/20261027000000_matches.sql`.
3. **Authentication → Sign In / Providers**: ative *Allow anonymous sign-ins*.
4. **Project Settings → API**: copie URL, anon key e service_role key para `.env.local`.

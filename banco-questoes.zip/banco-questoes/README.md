# Banco de Questões Gamificado — Etapa 2

**Abrir o preview:** `python scripts/gerar_preview.py` e depois abra [`preview_quiz.html`](preview_quiz.html) no navegador (filtros por área, mecânica, Bloom, fonte e base original; clique nas alternativas para ver o feedback; botão "Eliminar 2"; timer do jogo ligado por padrão).

| Arquivo | Conteúdo |
|---|---|
| [`01-AREAS.md`](01-AREAS.md) | As 6 áreas da roleta e onde entra cada matéria e lacuna do ENADE |
| [`02-SCHEMA.md`](02-SCHEMA.md) | Padrão Perguntados (4 alternativas), mecânicas e regras do validador |
| [`schema/questao.schema.json`](schema/questao.schema.json) | JSON Schema para o app |
| [`03-PROTOCOLO.md`](03-PROTOCOLO.md) | Passo a passo de geração e revisão |
| [`07-GUIA-MODO-JOGO.md`](07-GUIA-MODO-JOGO.md) | **Modo jogo:** limites de texto, conta de cabeça, formatos que funcionam no timer |
| [`playtest/RELATORIO-PLAYTEST.md`](playtest/RELATORIO-PLAYTEST.md) | Playtest com agentes-persona (professora, jogador, calouro) |
| [`lotes/lote-base-original.json`](lotes/lote-base-original.json) | **300 questões do jogo físico, refatoradas** |
| [`lotes/lote-00-piloto.json`](lotes/lote-00-piloto.json) | 47 questões inéditas do piloto (45 de 4 alternativas + 2 de desempate) |
| [`04-REVISAO-LOTE-00.md`](04-REVISAO-LOTE-00.md) · [`06-REVISAO-BASE-ORIGINAL.md`](06-REVISAO-BASE-ORIGINAL.md) | Revisões e correções |
| [`05-PLANO-DE-LOTES.md`](05-PLANO-DE-LOTES.md) | Plano dos próximos lotes |
| `scripts/` | `validar.py`, `gerar_preview.py`, `montar_base.py` (expande `base-original/refatoradas/*.json`) |
